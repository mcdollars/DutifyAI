import React from 'react';
import { Box } from '@mui/material';
import '../styles/Menu.css';
import DutifyMark from "../images/dutifymark.svg"
import { Typography } from 'antd';

interface MenuProps {
    onMenuClick: (menu: string) => void;
    selectedMenu: string;
}

const Menu: React.FC<MenuProps> = ({ onMenuClick, selectedMenu }) => {
    return (
        <Box className="menu-container" sx={{
            px: 2,
            py: 3
        }} gap={4.5}>
            <Box ml={0.5}>
                <img src={DutifyMark} alt="Logo" className="login-logo" />
            </Box >
            <Box gap={3.5} >
                <Typography>Calls</Typography>
                <Typography>Calls</Typography>
                <div
                    className={`menu-item ${selectedMenu === 'Calls' ? 'selected' : ''}`}
                    onClick={() => onMenuClick('Calls')}
                >
                    
                </div>
                <div
                    className={`menu-item ${selectedMenu === 'Integrations' ? 'selected' : ''}`}
                    onClick={() => onMenuClick('Integrations')}
                >
                    Integrations
                </div>
            </Box>
        </Box>
    );
};

export default Menu;