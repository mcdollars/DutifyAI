export const Integration = {
    ClickUp: "ClickUp",
    Jira: "Jira"
}
